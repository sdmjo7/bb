//
// Created by touva on 7/16/2020.
//

#ifndef PROJECT_X_STRINGS_H
#define PROJECT_X_STRINGS_H
#include <jni.h>
#include <unistd.h>
#include <cstdio>
#include <cstring>
#include <cstdlib>

#endif //PROJECT_X_STRINGS_H

typedef struct _monoString {
    void *klass;
    void *monitor;
    int length;
    char chars[1];

    int getLength() {
        return length;
    }

    char *getChars() {
        return chars;
    }
} monoString;

monoString *CreateMonoString(const char *str) {
    monoString *(*String_CreateString)(void *instance, const char *str) = (monoString *(*)(void *, const char *))getAbsoluteAddress(0xFF3DB4);

    return String_CreateString(NULL, str);
}